# NOTE: this is a hack and will downgrade the tzdata package. Use this instead:
# https://gist.github.com/bmaupin/16855ce1b2484c459f41ad836a7d3f2f
wget http://launchpadlibrarian.net/235298493/openjdk-6-jdk_6b38-1.13.10-1_amd64.deb
wget http://launchpadlibrarian.net/235298496/openjdk-6-jre_6b38-1.13.10-1_amd64.deb
wget http://launchpadlibrarian.net/235298494/openjdk-6-jre-headless_6b38-1.13.10-1_amd64.deb
wget http://launchpadlibrarian.net/235298487/openjdk-6-jre-lib_6b38-1.13.10-1_all.deb
wget http://launchpadlibrarian.net/250277191/tzdata_2016c-0ubuntu1_all.deb
wget http://launchpadlibrarian.net/250277190/tzdata-java_2016c-0ubuntu1_all.deb
sudo dpkg -i openjdk-6-jdk_6b38-1.13.10-1_amd64.deb openjdk-6-jre_6b38-1.13.10-1_amd64.deb openjdk-6-jre-headless_6b38-1.13.10-1_amd64.deb openjdk-6-jre-lib_6b38-1.13.10-1_all.deb tzdata_2016c-0ubuntu1_all.deb tzdata-java_2016c-0ubuntu1_all.deb
